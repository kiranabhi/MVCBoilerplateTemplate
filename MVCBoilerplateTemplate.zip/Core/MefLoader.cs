﻿using System.Collections.Generic;
using System.ComponentModel.Composition.Hosting;
using System.ComponentModel.Composition.Primitives;

namespace $safeprojectname$.Core
{
    public static class MefLoader
    {
        public static CompositionContainer Init()
        {
            return Init(null);
        }

        public static CompositionContainer Init(ICollection<ComposablePartCatalog> catalogParts)
        {
            //The following line does not work when running locally with unit tests
            //var catalog = new DirectoryCatalog(".", "Isbe.*.dll");

            //Only one class from each project needs to be added.
            var catalog = new AggregateCatalog();

            //catalog.Catalogs.Add(new AssemblyCatalog(typeof().Assembly));

            if (catalogParts != null)
            {
                foreach (var catalogPart in catalogParts)
                {
                    catalog.Catalogs.Add(catalogPart);
                }
            }

            var container = new CompositionContainer(catalog);

            return container;
        }
    }
}