﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition.Hosting;
using System.Web.Mvc;
using System.ComponentModel.Composition;
using System.Reflection;

namespace $safeprojectname$.Core
{
    public class MefDependencyResolver : IDependencyResolver
    {
        private readonly CompositionContainer _container;

        public MefDependencyResolver(CompositionContainer container)
        {
            _container = container;
        }

        public object GetService(Type serviceType)
        {
            if (serviceType == null)
                throw new ArgumentNullException(nameof(serviceType));

            var name = AttributedModelServices.GetContractName(serviceType);
            var export = _container.GetExportedValueOrDefault<object>(name);
            return export;
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            if (serviceType == null)
                throw new ArgumentNullException(nameof(serviceType));

            var exports = _container.GetExportedValues<object>(AttributedModelServices.GetContractName(serviceType));
            return exports;
        }
    }

    public static class MefConfig
    {
        public static void RegisterMef()
        {
            var catalog = new AggregateCatalog(
                    new DirectoryCatalog("."),
                    new AssemblyCatalog(Assembly.GetExecutingAssembly()));

            var resolver = new MefDependencyResolver(MefLoader.Init(catalog.Catalogs));

            // Install MEF dependency resolver for MVC
            DependencyResolver.SetResolver(resolver);
        }
    }
}