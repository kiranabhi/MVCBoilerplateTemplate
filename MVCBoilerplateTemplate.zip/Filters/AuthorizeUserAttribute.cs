﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Security.Claims;
using System.Threading;
using System.Linq;

namespace $safeprojectname$.Filters
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class AuthorizeUserAttribute : AuthorizeAttribute
    {
        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            var principal = (ClaimsPrincipal)Thread.CurrentPrincipal;
            var identity = (ClaimsIdentity)principal.Identity;

            if (identity.IsAuthenticated)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        protected override void HandleUnauthorizedRequest(System.Web.Mvc.AuthorizationContext filterContext)
        {
            filterContext.Result = new RedirectToRouteResult(
                    new RouteValueDictionary(
                        new
                        {
                            area = "",
                            controller = "Error",
                            action = "ShowError"
                        })
                    );
        }
    }
}